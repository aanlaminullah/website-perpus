<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dinas Kearsipan dan Perpustakaan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background-color: #f8f9fa;
            padding-top: 90px;
        }

        .header {
            background: linear-gradient(135deg, #2c3e50, #3498db);
            color: white;
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 999;
            transition: all 0.3s ease;
        }

        .header .logo,
        .header .site-title,
        .header .tagline,
        .header .nav-menu a {
            transition: all 0.3s ease;
        }

        .header.shrink {
            padding: 0.5rem 0;
            background: linear-gradient(135deg, #1a252f, #2980b9);
        }

        .header.shrink .logo {
            width: 40px;
            padding-top: 5px;
        }

        .header.shrink .site-title {
            font-size: 20px;
        }

        .header.shrink .tagline {
            font-size: 12px;
        }

        .header.shrink .nav-menu a {
            font-size: 14px;
        }

        .header-top {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            width: 50px;
            height: auto;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            flex-shrink: 0;
            padding-top: 10px;
        }

        .logo img {
            width: 100%;
            height: auto;
            object-fit: contain;
        }

        .site-title {
            font-size: 24px;
            font-weight: bold;
        }

        .tagline {
            font-size: 14px;
            opacity: 0.9;
            margin-top: 5px;
        }

        .nav-menu {
            display: flex;
            gap: 30px;
        }

        .nav-menu a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s;
        }

        .nav-menu a:hover {
            opacity: 0.8;
        }

        .hero-section {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: center;
        }

        .hero-content h1 {
            font-size: 36px;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        .hero-content p {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.8;
        }

        .cta-button {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .cta-button:hover {
            transform: translateY(-2px);
        }

        .hero-visual {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .hero-visual img {
            width: 100%;
            height: auto;
            max-width: 600px;
        }

        .stats-circle {
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3498db, #2980b9);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            position: relative;
        }

        .stats-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .stats-grid {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: -50px;
            position: relative;
            z-index: 2;
        }

        .stat-item {
            background: white;
            padding: 30px 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .stat-item:hover {
            transform: translateY(-5px);
        }

        .stat-number {
            font-size: 36px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .stat-label {
            color: #666;
            font-size: 14px;
        }

        .services-section {
            padding: 80px 0;
            background: white;
        }

        .section-title {
            text-align: center;
            font-size: 32px;
            color: #2c3e50;
            margin-bottom: 50px;
        }

        .services-grid {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }

        .service-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: all 0.3s;
            border-top: 4px solid #3498db;
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }

        .service-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #3498db, #2980b9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 24px;
            color: white;
        }

        .service-card h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 18px;
        }

        .service-card p {
            color: #666;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .service-link {
            color: #3498db;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
        }

        .news-section {
            padding: 80px 0;
            background: #f8f9fa;
        }

        .news-grid {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }

        .news-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .news-card:hover {
            transform: translateY(-5px);
        }

        .news-image {
            width: 100%;
            height: 200px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #eee;
        }

        .news-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .news-content {
            padding: 25px;
        }

        .news-date {
            color: #666;
            font-size: 12px;
            margin-bottom: 10px;
        }

        .news-title {
            color: #2c3e50;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            line-height: 1.4;
        }

        .news-excerpt {
            color: #666;
            font-size: 14px;
            line-height: 1.6;
        }

        .footer {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            padding: 50px 0 20px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 40px;
        }

        .footer-section h3 {
            margin-bottom: 20px;
            font-size: 18px;
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section ul li a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }

        .footer-section ul li a:hover {
            color: white;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }

        .contact-info {
            color: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .header-top {
                flex-direction: column;
                gap: 20px;
            }

            .nav-menu {
                gap: 15px;
            }

            .hero-section {
                grid-template-columns: 1fr;
                text-align: center;
                padding: 40px 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
                margin-top: 20px;
            }

            .services-grid,
            .news-grid,
            .footer-content {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .hero-content h1 {
                font-size: 28px;
            }
        }
    </style>
</head>

<body>
    <header class="header">
        <div class="header-top">
            <div class="logo-section">
                <div class="logo">
                    <img src="/logo-pemda.png" alt="Dinas Logo" />
                </div>
                <div>
                    <div class="site-title">Dinas Kearsipan dan Perpustakaan</div>
                    <div class="tagline">
                        Pelayanan Informasi dan Dokumentasi Terpadu
                    </div>
                </div>
            </div>

            <nav class="nav-menu">
                <a href="#beranda">Beranda</a>
                <a href="#profil">Profil</a>
                <a href="#layanan">Layanan</a>
                <a href="#berita">Berita</a>
                <a href="#kontak">Kontak</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero-section" id="beranda">
            <div class="hero-content">
                <h1>Selamat Datang</h1>
                <p>
                    Sistem Informasi Kearsipan dan Perpustakaan Digital yang menyediakan
                    layanan terbaik dalam pengelolaan arsip, dokumentasi, dan
                    perpustakaan untuk kemudahan akses informasi publik yang transparan
                    dan akuntabel.
                </p>
                <button class="cta-button">Jelajahi Layanan</button>
            </div>
            <div class="hero-visual">
                <img src="vector2.png" alt="">
            </div>
        </section>

        <section class="stats-grid">
            <div class="stat-item">
                <div class="stat-number">15,450</div>
                <div class="stat-label">Koleksi Buku</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">8,230</div>
                <div class="stat-label">Dokumen Arsip</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">2,150</div>
                <div class="stat-label">Anggota Aktif</div>
            </div>
        </section>

        <section class="services-section" id="layanan">
            <h2 class="section-title">Layanan Kami</h2>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">📋</div>
                    <h3>LAYANAN KEARSIPAN</h3>
                    <p>
                        Pengelolaan dan pelayanan arsip dinamis dan statis sesuai dengan
                        standar kearsipan nasional.
                    </p>
                    <a href="#" class="service-link">Selengkapnya →</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">📚</div>
                    <h3>LAYANAN PERPUSTAKAAN</h3>
                    <p>
                        Peminjaman buku, jurnal, dan koleksi digital dengan sistem otomasi
                        perpustakaan modern.
                    </p>
                    <a href="#" class="service-link">Selengkapnya →</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">🔍</div>
                    <h3>LAYANAN INFORMASI PUBLIK</h3>
                    <p>
                        Penyediaan informasi publik yang mudah diakses sesuai UU
                        Keterbukaan Informasi Publik.
                    </p>
                    <a href="#" class="service-link">Selengkapnya →</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">💾</div>
                    <h3>DIGITALISASI ARSIP</h3>
                    <p>
                        Layanan digitalisasi dokumen dan arsip untuk kemudahan akses dan
                        preservasi jangka panjang.
                    </p>
                    <a href="#" class="service-link">Selengkapnya →</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">🎓</div>
                    <h3>LITERASI INFORMASI</h3>
                    <p>
                        Program pelatihan dan edukasi literasi informasi untuk masyarakat
                        dan instansi.
                    </p>
                    <a href="#" class="service-link">Selengkapnya →</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">📱</div>
                    <h3>LAYANAN MOBILE</h3>
                    <p>
                        Aplikasi mobile untuk akses layanan perpustakaan dan kearsipan
                        secara online.
                    </p>
                    <a href="#" class="service-link">Selengkapnya →</a>
                </div>
            </div>
        </section>

        <section class="news-section" id="berita">
            <h2 class="section-title">Berita Terkini</h2>
            <div class="news-grid">
                <article class="news-card">
                    <div class="news-image"><img src="/news1.jpg" alt=""></div>
                    <div class="news-content">
                        <div class="news-date">25 Agustus 2024</div>
                        <h3 class="news-title">
                            Peluncuran Sistem Perpustakaan Digital Terintegrasi
                        </h3>
                        <p class="news-excerpt">
                            Dinas meluncurkan sistem perpustakaan digital yang terintegrasi
                            dengan e-government untuk kemudahan akses masyarakat.
                        </p>
                    </div>
                </article>
                <article class="news-card">
                    <div class="news-image"><img src="/news2.jpg" alt=""></div>
                    <div class="news-content">
                        <div class="news-date">20 Agustus 2024</div>
                        <h3 class="news-title">
                            Raih Penghargaan Perpustakaan Terbaik Tingkat Provinsi
                        </h3>
                        <p class="news-excerpt">
                            Perpustakaan daerah meraih penghargaan sebagai perpustakaan
                            terbaik tingkat provinsi dalam kategori inovasi layanan.
                        </p>
                    </div>
                </article>
                <article class="news-card">
                    <div class="news-image"><img src="/news3.jpg" alt=""></div>
                    <div class="news-content">
                        <div class="news-date">15 Agustus 2024</div>
                        <h3 class="news-title">Workshop Manajemen Arsip untuk ASN</h3>
                        <p class="news-excerpt">
                            Kegiatan pelatihan manajemen arsip diselenggarakan untuk
                            meningkatkan kompetensi ASN dalam pengelolaan dokumen.
                        </p>
                    </div>
                </article>
            </div>
        </section>
    </main>

    <footer class="footer" id="kontak">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <div class="contact-info">
                    <p>📍 Jl. Merdeka No. 123<br />Kota Lumajang, Jawa Timur</p>
                    <p>📞 (0334) 123-4567</p>
                    <p>✉️ info@disarpus.lumajang.go.id</p>
                    <p>🕒 Senin - Jumat: 08:00 - 16:00</p>
                </div>
            </div>
            <div class="footer-section">
                <h3>Layanan</h3>
                <ul>
                    <li><a href="#">Perpustakaan Digital</a></li>
                    <li><a href="#">Arsip Online</a></li>
                    <li><a href="#">Informasi Publik</a></li>
                    <li><a href="#">E-Book</a></li>
                    <li><a href="#">Katalog Online</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Informasi</h3>
                <ul>
                    <li><a href="#">Profil Dinas</a></li>
                    <li><a href="#">Visi & Misi</a></li>
                    <li><a href="#">Struktur Organisasi</a></li>
                    <li><a href="#">Tupoksi</a></li>
                    <li><a href="#">Regulasi</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Tautan</h3>
                <ul>
                    <li><a href="#">Portal Lumajang</a></li>
                    <li><a href="#">PPID</a></li>
                    <li><a href="#">E-Government</a></li>
                    <li><a href="#">Perpusnas RI</a></li>
                    <li><a href="#">ANRI</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>
                &copy; 2024 Dinas Kearsipan dan Perpustakaan Kabupaten Lumajang. All
                Rights Reserved.
            </p>
        </div>
    </footer>

    <script>
        // Smooth scrolling untuk navigasi
        document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
            anchor.addEventListener("click", function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute("href"));
                if (target) {
                    target.scrollIntoView({
                        behavior: "smooth",
                        block: "start",
                    });
                }
            });
        });

        // Animasi counter untuk statistik
        function animateCounter(element, target) {
            let current = 0;
            const increment = target / 100;
            const timer = setInterval(() => {
                current += increment;
                element.textContent = Math.floor(current).toLocaleString("id-ID");
                if (current >= target) {
                    element.textContent = target.toLocaleString("id-ID");
                    clearInterval(timer);
                }
            }, 20);
        }

        // Intersection Observer untuk animasi
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    const statNumbers = entry.target.querySelectorAll(".stat-number");
                    const targets = [15450, 8230, 2150];
                    statNumbers.forEach((num, index) => {
                        animateCounter(num, targets[index]);
                    });
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(document.querySelector(".stats-grid"));

        // CTA Button action
        document.querySelector(".cta-button").addEventListener("click", () => {
            document.querySelector("#layanan").scrollIntoView({
                behavior: "smooth",
            });
        });

        window.addEventListener("scroll", function() {
            const header = document.querySelector(".header");
            if (window.scrollY > 50) {
                header.classList.add("shrink");
            } else {
                header.classList.remove("shrink");
            }
        });
    </script>
</body>

</html>
<?php /**PATH D:\project\website-perpus\resources\views/landing.blade.php ENDPATH**/ ?>